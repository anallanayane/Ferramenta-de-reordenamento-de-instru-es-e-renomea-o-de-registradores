#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

typedef struct Instrucao {
    string opcode;
    string op1;
    string op2;
    string op3;
} Instrucao;

Instrucao ler_instrucao(ifstream& file) {
    Instrucao inst;

    file >> inst.opcode;
    file >> inst.op1;
    file >> inst.op2;
    file >> inst.op3;

    return inst;
}

vector<Instrucao> ler_instrucoes_do_arquivo(char* filename) {
    ifstream file;
    Instrucao inst;
    vector<Instrucao> insts;

    file.open(filename);

    while (file.good()) {
        inst = ler_instrucao(file);
        insts.push_back(inst);
    }

    insts.pop_back();
    return insts;
}

string get_destino(Instrucao& inst) {
    string res = "";

    if (inst.opcode == "sw") { // sw n tem destino pq n escreve
        return res;
    } else {
        return inst.op1;
    }
}

string get_operando1(Instrucao& inst) {
    if (inst.opcode == "sw") {
        return inst.op1;
    } else {
        return inst.op2;
    }
}

string get_operando2(Instrucao& inst) {
    string res = "";

    if (inst.opcode == "sw") {
        return inst.op1;
    } else {
        return inst.op3;
    }
}

bool has_read_after_write_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino = get_destino(insts[i]);
    string op1     = get_operando1(insts[j]);
    string op2     = get_operando2(insts[j]);

    return destino == op1 || destino == op2;
}

bool has_write_after_read_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino = get_destino(insts[j]);
    string op1     = get_operando1(insts[i]);
    string op2     = get_operando2(insts[i]);

    return destino == op1 || destino == op2;
}

bool has_write_after_write_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino1 = get_destino(insts[j]);
    string destino2 = get_destino(insts[i]);

    return destino1 == destino2 && destino1 != "";
}

vector<int> obter_dependencias_read_after_write(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_read_after_write_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

vector<int> obter_dependencias_write_after_read(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_write_after_read_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

vector<int> obter_dependencias_write_after_write(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_write_after_write_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

void imprimir_vetor_de_dependencias(string header, vector<int>& dependencias) {
    int i;

    cout << header << " = {";

    if (dependencias.size() > 0) {
        for (i = 0; i < dependencias.size() - 1; ++i) {
            cout << dependencias[i] << ", ";
        }

        cout << dependencias[i];
    }

    cout << "};";
}

void imprimir_instrucoes(vector<Instrucao>& insts) {
    vector<int> dependencias;

    cout << "#inst\ttipo_inst\tdest\t\top1\t\top2\t\t#inst_recebe_resultado\n";

    for (int i = 0; i < insts.size(); ++i) {
        cout << i << '\t' << insts[i].opcode << "\t\t"
            << insts[i].op1 << "\t\t" << insts[i].op2 << "\t\t"
            << insts[i].op3 << "\t\t";


        dependencias = obter_dependencias_read_after_write(insts, i);
        imprimir_vetor_de_dependencias("RW", dependencias);

        dependencias = obter_dependencias_write_after_read(insts, i);
        imprimir_vetor_de_dependencias(" WR", dependencias);

        dependencias = obter_dependencias_write_after_write(insts, i);
        imprimir_vetor_de_dependencias(" WW", dependencias);
        cout << endl;
    }
}

/* Aqui eh que eu vou comear a implementar a reordenacao */


/* Fim da reordenacao */

int main(int argc, char* argv[]) {
    vector<Instrucao> insts;

    if (argc != 2) {
        cout << "Error: missing input file\n";
        cout << "Usage: " << argv[0] << " input.txt\n";
        return 1;
    }

    insts = ler_instrucoes_do_arquivo(argv[1]);
    imprimir_instrucoes(insts);

}
