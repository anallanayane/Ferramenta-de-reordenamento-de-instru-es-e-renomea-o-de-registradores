#include <iostream>
#include <fstream>
#include <iomanip>
#include <cctype>
#include <string>
#include <string.h>

using namespace std;
#define MAX 100

void loop(){
	//DECLARANDO VARIÁVEIS
	ifstream txtFile;
	string palavra,linha;
	char arquivo[20];
	string matriz[MAX][MAX];
	//ABRINDO ARQUIVO
	cout<<endl<<"DIGITE O NOME DO ARQUIVO QUE DESEJA ABRIR: ";
	cin.getline (arquivo,20);
	txtFile.open(arquivo);
	// TESTA SE CONSEGUIU ABRIR
	if(!txtFile){
		cout<<"ERRO AO ABRIR ARQUIVO"<<endl<<endl<<"O PROGRAMA SERÁ ENCERRADO..."<<endl<<endl;
	}

	int i=1,j=1,aux=0;
	char c;
	while(txtFile.get(c)){ // ENQUANTO CONSEGUIR LER ALGUM CARACTERE ELE ENTRA NO LAÇO
		if(!isspace(c) && !iscntrl(c)){ // FUNÇÕES PARA SABER SE O CARACTERE PEGO FOI UM ESPAÇO EM BRANCO OU SE FOI UMA QUEBRA DE LINHA
			palavra += c; // CONCATENA A LETRA A STRING PALAVRA
			aux = 0;
		}
		else if((isspace(c) || iscntrl(c)) && aux == 0){ // se encontrar um espaço entra
			aux++;
			matriz[i][j] = palavra; // MATRIZ NA POSIÇÃO [I][J] RECEBE A STRING PALAVRA
			palavra = ""; //'RESETA' A STRING DE PALAVRA
			j++; //aAVANÇA UMA POSIÇÃO NA COLUNA
		}
		if( j > 6){
		i++; // AVANÇA UMA POSIÇÃO NA LINHA
		j=1; //ZERA A COLUNA PARA QUE VOLTE PARA POSIÇÃO INICIAL
		}
	}

	/*
	*** ESSE TRECHO DE CÓDIGO É PARA IMPRIMIR A MATRIZ, UTILIZE SEMPRE QUE QUISER TESTAR SE A MATRIZ ESTÁ CORRETA
	*/
	for(int a = 1; a <=i ; a++){
			for(int b = 1; b <= 6; b++){
				cout<<setw(10)<<matriz[a][b]<<"     ";
			}
			cout<<endl;
		}

    /*
	*** TEM QUE TRABALHAR NA MATRIZ AGORA... TEM QUE TER COMO BASE SEMPRE A COLUNA 'dest' que é a 3.
	*** COMO FAZER: ATRIBUIR UMA VARIAVEL t(indicando tempo) PARA CADA LINHA.
	*** EX:t1(variavel para primeira linha) = 1; t2(variavel para segunda linha) = 2;
	*** A PARTIR DAI VAI COMPARANDO AS VARIAVEIS 'op1' e 'op2' DE CADA LINHA COM A VARIAVEL 'dest' DAS LINHAS DE CIMA.
	*** EX: A VARIAVEL 'op1' DA LINHA 2 TEM COMO t2 = 2, A PARTIR DAÍ COMPARA A STRING DESSA VARIAVEL(linha 2 op1) COM A STRING DA VARIAVEL 'dest' DAS
	*** LINHAS ACIMA, SE FOR IGUAL FAZ OUTRA COMPARAÇÃO: (t2 - t1) < 5 (É NECESSARIO PARA SABER SE A VARIAVEL DA LINHA DE CIMA AINDA ESTA EM ALGUM ESTAGIO
	***QUE NAO SEJA O WRITE BACK, JÁ QUE PRA ESSE PROJETO É UTILIZADO UM PIPELINE DE 5 ESTAGIOS) SE SIM: HÁ DEPENDENCIA(TEM QUE TROCAR AS LINHAS DE LUGAR),
	***SE NÃO: DEIXA COMO ESTÁ.
	*/

    //Fecha o arquivo
    txtFile.close();
}


int main()
{
	loop();
	return 0;
}
