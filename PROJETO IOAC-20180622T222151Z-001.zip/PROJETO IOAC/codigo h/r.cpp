#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

typedef struct Instrucao {
    string opcode;
    string op1;
    string op2;
    string op3;
} Instrucao;

Instrucao ler_instrucao(ifstream& file) {
    Instrucao inst;

    file >> inst.opcode;
    file >> inst.op1;
    file >> inst.op2;
    file >> inst.op3;

    return inst;
}

vector<Instrucao> ler_instrucoes_do_arquivo(char* filename) {
    ifstream file;
    Instrucao inst;
    vector<Instrucao> insts;

    file.open(filename);

    while (file.good()) {
        inst = ler_instrucao(file);
        insts.push_back(inst);
    }

    return insts;
}

void imprimir_instrucoes(vector<Instrucao>& insts) {
    cout << "#inst\ttipo_inst\tdest\t\top1\t\top2\t\t#inst_recebe_resultado\n";

    for (int i = 0; i < insts.size(); ++i) {
        cout << i << '\t' << insts[i].opcode << "\t\t"
            << insts[i].op1 << "\t\t" << insts[i].op2 << "\t\t"
            << insts[i].op3 << "\t\t" << "TODO\n";
    }
}

int main(int argc, char* argv[]) {
    vector<Instrucao> insts;

    if (argc != 2) {
        cout << "Error: missing input file\n";
        cout << "Usage: " << argv[0] << " input.txt\n";
        return 1;
    }

    insts = ler_instrucoes_do_arquivo(argv[1]);
    imprimir_instrucoes(insts);
}
