#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

typedef struct Instrucao {
    string opcode;
    string op1;
    string op2;
    string op3;
} Instrucao;

Instrucao ler_instrucao(ifstream& file) {
    Instrucao inst;

    file >> inst.opcode;
    file >> inst.op1;
    file >> inst.op2;
    file >> inst.op3;

    return inst;
}

vector<Instrucao> ler_instrucoes_do_arquivo() {
    ifstream file;
    Instrucao inst;
    vector<Instrucao> insts;

    file.open("exemplo_pdf.txt");

    while (file.good()) {
        inst = ler_instrucao(file);
        insts.push_back(inst);
    }

    insts.pop_back();
    return insts;
}

/* Essa funcao recebe como parametro um vetor de instrucoes e a i-esima
 * instrucao desse vetor. Essa i-esima instrucao sobrescreve algum operando
 * A funcao deve, entao, retornar a posicao da proxima instrucao que sobrescreve
 * o mesmo operando.
 *
 * Exemplo
 * 0    add r1  r2  r3
 * 1    sub r2  r3  r4
 * 2    sub r5  r5  r5
 * 3    mul r1  r1  r1
 * 4    div r7  r7  r8
 *
 * Chamando a funcao com esse vetor e passando a posicao 0, a funcao retornara
 * o indice 4, que representa a instrucao div que sobrescreve o registrador r1
 * escrito pela instrucao add no indice 0. Se n houver instrucao que sobrescreva
 * deve-se retornar a posicao da ultima instrucao + 1
 */
int achar_instrucao_que_sobrescreve(vector<Instrucao>& insts, int i) {
    for (int j = i + 1; j < insts.size(); ++j) {
        if (insts[i].op1 == insts[j].op1) {
            return j;
        }
    }
    return insts.size();
}

vector<int> obter_instrucoes_destino(vector<Instrucao>& insts, int i) {
    int next;
    vector<int> resultado;

    next = achar_instrucao_que_sobrescreve(insts, i);

    /* so procura a partir da proxima instrucao ate a instrucao que sobrescreve o operando */
    for (int k = i + 1; k < next; ++k) {
        if (insts[i].op1 == insts[k].op2 || insts[i].op1 == insts[k].op3) {
            //if(k<=5) // se a dependencia for maior que um intervalo de 5 linhas ele n coloca no vetor de dependencias
                resultado.push_back(k);
        }
    }

    return resultado;
}

void imprimir_vetor_de_dependencias(vector<int>& dependencias,vector<Instrucao>& insts) {
    int i;

    if (dependencias.size() > 0) {
        for (i = 0; i < dependencias.size() - 1; ++i) {
            cout << dependencias[i] << ", ";
        }
        cout << dependencias[i];
    }
}

void imprimir_instrucoes(vector<Instrucao>& insts) {
    vector<int> dependencias;

    cout << "#inst\ttipo_inst\tdest\t\top1\t\top2\t\t#inst_recebe_resultado\n";

    for (int i = 0; i < insts.size(); ++i) {
        cout << i << '\t' << insts[i].opcode << "\t\t"
            << insts[i].op1 << "\t\t" << insts[i].op2 << "\t\t"
            << insts[i].op3 << "\t\t";

        dependencias = obter_instrucoes_destino(insts, i);
        imprimir_vetor_de_dependencias(dependencias,insts);
        cout << endl;
    }
}

void reordenamento_instrucoes(vector<Instrucao>& insts)
{
    int i, j;
    Instrucao temp;

    for (i = 1; i>= 8; i++){
        for(j = 1; j >= 6; j++){
            if (insts[j].op2 != insts[i+1].op1 || insts[j].op3 != insts[i+1].op1){
                    temp = insts[j];
                    insts[j] = insts[i+1];
                    insts[i+1] = temp;
                }
            else{
                continue;
            }
        }
    }
}

void reordenamento_instrucoes2(vector<Instrucao>& insts, vector<int>& dependencias)
{
    int i = insts.size()-1;     //atual
    int j = insts.size()-2;     //cima
    Instrucao temp;

    while(j >= 0)
    {
        if(insts[i].op2 == insts[j].op1 || insts[i].op3 == insts[j].op1){
            i--;
            j--;
        }
        else if(i+1 <= insts.size() && (insts[i+1].op2 == insts[j].op1 || insts[j+1].op3 == insts[j].op1)){
                i--;
                j--;
        }
        else if(j-1 >= 0 && (insts[i].op2 == insts[j-1].op1 || insts[i].op3 == insts[j-1].op1)){
            i--;
            j--;
        }
        else{
            temp = insts[i];
            insts[i] = insts[j];
            insts[j] = temp;
            i--;
            j--;
        }
    }
}

/*void reordenamento_instrucoes3(vector<Instrucao>& insts)
{
    int i, j;
    Instrucao temp;

    for (i = insts.size(); i>= insts.size-1(); i--){
        for(j = 1; j <= insts.size(); j++){
            if (insts[j].op2 != insts[i-1].op1 || insts[j].op3 != insts[i-1].op1){
                    temp = insts[j];
                    insts[j] = insts[i];
                    insts[i] = temp;
            }
            else{
                continue;
            }
        }
    }

    /*for (i = 7; i >= 6; i--){
        for(j = 1; j <= 6; j++){


}*/



int main(int argc, char* argv[]) {
    vector<Instrucao> insts;
    vector<int> dependencias;
    /*if (argc != 2) {
        cout << "Error: missing input file\n";
        cout << "Usage: " << argv[0] << " input.txt\n";
        return 1;
    }*/

    insts = ler_instrucoes_do_arquivo();
    imprimir_instrucoes(insts);

    cout << achar_instrucao_que_sobrescreve(insts, 0) << endl;


    cout <<endl << "Novo Grafo: " <<endl<<endl;
    //reordenamento_instrucoes(insts);
    reordenamento_instrucoes2(insts);


    return 0;
}
