#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

typedef struct Instrucao {
    string opcode;
    string op1;
    string op2;
    string op3;
} Instrucao;

Instrucao ler_instrucao(ifstream& file) {
    Instrucao inst;

    file >> inst.opcode;
    file >> inst.op1;
    file >> inst.op2;
    file >> inst.op3;

    return inst;
}

vector<Instrucao> ler_instrucoes_do_arquivo() {
    ifstream file;
    Instrucao inst;
    vector<Instrucao> insts;

    file.open("exemplo_pdf.txt");

    while (file.good()) {
        inst = ler_instrucao(file);
        insts.push_back(inst);
    }

    insts.pop_back();
    return insts;
}

string get_destino(Instrucao& inst) {
    string res = "";

    if (inst.opcode == "sw") { // sw n tem destino pq n escreve
        return res;
    } else {
        return inst.op1;
    }
}

string get_operando1(Instrucao& inst) {
    if (inst.opcode == "sw") {
        return inst.op1;
    } else {
        return inst.op2;
    }
}

string get_operando2(Instrucao& inst) {
    string res = "";

    if (inst.opcode == "sw") {
        return inst.op1;
    } else {
        return inst.op3;
    }
}

bool has_read_after_write_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino = get_destino(insts[i]);
    string op1     = get_operando1(insts[j]);
    string op2     = get_operando2(insts[j]);

    return destino == op1 || destino == op2;
}

bool has_write_after_read_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino = get_destino(insts[j]);
    string op1     = get_operando1(insts[i]);
    string op2     = get_operando2(insts[i]);

    return destino == op1 || destino == op2;
}

bool has_write_after_write_dependency(vector<Instrucao>& insts, int i, int j) {
    string destino1 = get_destino(insts[j]);
    string destino2 = get_destino(insts[i]);

    return destino1 == destino2 && destino1 != "";
}

vector<int> obter_dependencias_read_after_write(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_read_after_write_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

vector<int> obter_dependencias_write_after_read(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_write_after_read_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

vector<int> obter_dependencias_write_after_write(vector<Instrucao>& insts, int i) {
    vector<int> resultado;

    for (int j = i + 1; j < insts.size(); ++j) {
        if (has_write_after_write_dependency(insts, i, j)) {
            resultado.push_back(j);
        }
    }

    return resultado;
}

void imprimir_vetor_de_dependencias(string header, vector<int>& dependencias) {
    int i;

    cout << header << " = {";

    if (dependencias.size() > 0) {
        for (i = 0; i < dependencias.size() - 1; ++i) {
            cout << dependencias[i] << ", ";
        }

        cout << dependencias[i];
    }

    cout << "};";
}

void imprimir_instrucoes(vector<Instrucao>& insts) {
    vector<int> dependencias;

    cout << "#inst\ttipo_inst\tdest\t\top1\t\top2\t\t#dependencias\n";

    for (int i = 0; i < insts.size(); ++i) {
        cout << i << '\t' << insts[i].opcode << "\t\t"
            << insts[i].op1 << "\t\t" << insts[i].op2 << "\t\t"
            << insts[i].op3 << "\t\t";


        dependencias = obter_dependencias_read_after_write(insts, i);
        imprimir_vetor_de_dependencias("RW", dependencias);

        dependencias = obter_dependencias_write_after_read(insts, i);
        imprimir_vetor_de_dependencias(" WR", dependencias);

        dependencias = obter_dependencias_write_after_write(insts, i);
        imprimir_vetor_de_dependencias(" WW", dependencias);
        cout << endl;
    }
}

/* Aqui eh que eu vou comear a implementar a reordenacao */

/* Retorna uma matriz zerada de inteiros NxM onde N eh o numero de linhas */
typedef vector<vector<int> > Matriz;

Matriz gerar_matriz(int N, int M) {
    Matriz matriz;

    matriz.resize(N);

    for (int i = 0; i < N; ++i) {
        matriz[i].resize(M);

        for (int j = 0; j < M; ++j) {
            matriz[i][j] = 0;
        }
    }

    return matriz;
}

/* Retorna um grafo representado como matriz */
Matriz montar_grafo_dependencia(vector<Instrucao>& insts) {
    int N = insts.size();
    vector< vector<int> > matriz;
    vector<int> dependencias;

    matriz = gerar_matriz(N, N);

    for (int i = 0; i < N; ++i) {
        dependencias = obter_dependencias_read_after_write(insts, i);

        for (int j = 0; j < dependencias.size(); ++j) {
            matriz[i][dependencias[j]] = 1;
        }

        dependencias = obter_dependencias_write_after_read(insts, i);

        for (int j = 0; j < dependencias.size(); ++j) {
            matriz[i][dependencias[j]] = 1;
        }

        dependencias = obter_dependencias_write_after_write(insts, i);

        for (int j = 0; j < dependencias.size(); ++j) {
            matriz[i][dependencias[j]] = 1;
        }
    }

    return matriz;
}

/* Retorna os vertices/instrucoes que nao possuem dependencias */
vector<int> pegar_candidatos_livres(Matriz& matriz) {
    vector<int> res;
    int N = matriz.size();
    int M = matriz[0].size();
    bool achou;

    for (int j = 0; j < M; ++j) {
        achou = false;

        for (int i = 0; i < N; ++i) {
            if (matriz[i][j] == 1) {
                achou = true; // existe pelo menos uma dependencia
            }
        }

        if (achou == false && matriz[j][j] != -1) {
            res.push_back(j);
        }
    }

    return res;
}

void zerar_linha(Matriz& matriz, int linha) {
    for (int i = 0; i < matriz[linha].size(); ++i) {
        matriz[linha][i] = 0;
    }
}

// Funcao que realiza a ordenacao das instrucoes
vector<Instrucao> escalonar(vector<Instrucao>& insts) {
    vector<Instrucao> res;
    vector<int> escalonamento;
    vector<int> candidatos;
    Matriz matriz;

    matriz = montar_grafo_dependencia(insts);
    int N = matriz.size();
    int M = matriz[0].size();

    while (true) {
        candidatos = pegar_candidatos_livres(matriz);

        if (candidatos.size() == 0) {
            break;
        }

        // adiciona os candidatos livres ao escalonamento atual
        for (int k = 0; k < candidatos.size(); ++k) {
            escalonamento.push_back(candidatos[k]);
        }

        // remove as dependencias
        for (int k = 0; k < candidatos.size(); ++k) {
            zerar_linha(matriz, candidatos[k]);
            matriz[candidatos[k]][candidatos[k]] = -1; // matriz[C][C] indica se elemento ja foi usado anteriormente: -1 = ja foi, -1 != n foi
        }

        imprimir_vetor_de_dependencias("", candidatos);
        cout << endl;
    }

    // Gera o novo escalonamento
    for (int i = 0; i < escalonamento.size(); ++i) {
        res.push_back(insts[escalonamento[i]]);
    }

    return res;
}

/* Fim da reordenacao */

int main(int argc, char* argv[]) {
    vector<Instrucao> insts;
    vector<Instrucao> escalonado;

    /*if (argc != 2) {
        cout << "Error: missing input file\n";
        cout << "Usage: " << argv[0] << " input.txt\n";
        return 1;
    }*/

    insts = ler_instrucoes_do_arquivo();
    imprimir_instrucoes(insts);

    cout<<endl << "";
    escalonado = escalonar(insts);

    cout << endl << "Depois do escalonamento...\n\n";
    imprimir_instrucoes(escalonado);

    return 0;
}
