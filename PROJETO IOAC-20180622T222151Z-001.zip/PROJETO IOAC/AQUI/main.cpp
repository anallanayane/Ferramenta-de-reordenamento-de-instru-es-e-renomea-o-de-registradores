#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;
#define MAX 10

void loop(){
	ifstream txtFile;
	string palavra;
	string linha;
	string matriz[10][6];
	int a;
	//abrindo arquivo
	txtFile.open("abra");


	//Lendo caractere a caractere
	int i=1,j=1;
	while(!txtFile.eof()){ //ENQUANTO CONSEGUIR LER O ARQUIVO
		while(getline(txtFile,linha)){ // ENQUANTO CONSEGUIR PEGAR AS LINHAS
			for( a = 1; a <= linha.size(); a++){ //enquanto n chega no final da linha vai pegando cada palavra letra a letra
				if(linha[a] != ' '){
					palavra += linha[a]; // concatena a letra a string palavra
				}
				else if(linha[a-1] != ' ' && linha[a] == ' '){ // se encontrar um espaço entra
					matriz[i][j] = palavra; // matriz na posição [i][j] recebe a string formada
					palavra = ""; //'reseta' a string palavra
					j++; //avança uma posiçao na coluna
				}
			}
		}
		i++;
	}

	//imprime a matriz pra o caso de teste que ele passou(falta colocar pra qualquer caso)... obs: isso é so pra testar a matriz
	for(int a = 1; a <= 8 ; a++){
			for(int b = 1; b <= 6; b++){
				cout<< matriz[a][b]<<"     ";
			}
			cout<<endl;
		}

	//Fecha o arquivo
	txtFile.close();


}
int main(){
	loop();
	return 0;
}
/*
3 while
while(endof){
	while(endline){
		while(caractere != " "){
		atual = char onde esta parado( vai concatenando ate encontrar o espaço);
		}
	}
}


*/
